package com.example.contractorcalculatorinterface;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button calculate;
    TextView textView;
    TextView textView2;
    TextView textView3;
    EditText editText;
    EditText editText2;
    Double labor;
    Double material;
    Double tax;
    Double subtotal;
    Double total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculate = (Button) findViewById(R.id.button);
        editText = (EditText) findViewById(R.id.etLabor);
        editText2 = (EditText) findViewById(R.id.etMaterial);
        textView = (TextView) findViewById(R.id.SubTotal);
        textView2= (TextView) findViewById(R.id.etTax);
        textView3= (TextView) findViewById(R.id.Total);

        calculate.setOnClickListener(this);

    }

    @Override
    public void onClick(View view)
    {
        labor = Double.parseDouble(editText.getText().toString());
        material = Double.parseDouble(editText2.getText().toString());
        if(view.getId() == calculate.getId())
        {
            subtotal = labor + material;
            subtotal = Math.round(subtotal * 100.00)/100.00;
            tax = subtotal * 0.05;
            total = tax + subtotal;
            textView.setText("SubTotal:    $" +subtotal.toString());
            textView2.setText("Tax:     $" +tax.toString());
            textView3.setText("Total:     $" +total.toString());
        }
    }
}