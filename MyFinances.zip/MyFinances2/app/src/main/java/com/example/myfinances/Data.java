package com.example.myfinances;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

 class Data {
    private SQLiteDatabase database;
    private final DBHelper dbHelper;

    public Data(Context context){dbHelper = new DBHelper(context);}

    public void open() throws SQLException{
        database = dbHelper.getWritableDatabase();
    }

    public void close(){dbHelper.close();}

    public boolean insertCDs(CDs cDs){
        boolean didSucceed = false;

        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("accountNumber", cDs.getAccountNumber());
            initialValues.put("initialBalance", cDs.getInitBalance());
            initialValues.put("currentBalance", cDs.getCurrentBalance());
            initialValues.put("interestRate", cDs.getInterestRate());


            didSucceed =  database.insert("MyFinances", null, initialValues) > 0;
        }
        catch (Exception e){

        }
        return didSucceed;
    }

    public boolean insertLoans(Loans loans){
        boolean didSucceed = false;

        try {
            ContentValues initialValues = new ContentValues();
            initialValues.put("accountNumber", loans.getAccountNumber());
            initialValues.put("initialBalance", loans.getInitBalance());
            initialValues.put("currentBalance", loans.getCurrentBalance());
            initialValues.put("paymentAmount", loans.getPaymentAmount());
            initialValues.put("interestRate", loans.getInterestRate());
            didSucceed =  database.insert("MyFinances", null, initialValues) > 0;
        }
        catch (Exception e)
        {
        }
        return didSucceed;
    }

    public boolean insertChecking(CheckingAccount checkingAccount){
        boolean didSucceed = false;

        try {
            ContentValues initialValues = new ContentValues();
            initialValues.put("accountNumber", checkingAccount.getAccountNumber());
            initialValues.put("currentBalance", checkingAccount.getCurrentBalance());

            didSucceed =  database.insert("MyFinances", null, initialValues) > 0;
        }
        catch (Exception e)
        {
        }
        return didSucceed;
    }
}