package com.example.myfinances;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CDs cDs;
    private Loans loans;
    private CheckingAccount checkingAccount;

    EditText etAccountNumber;
    EditText etInitBalance;
    EditText etCurrentBalance;
    EditText etPaymentAmount;
    EditText etInterestRate;
    Button btSave;
    Button btCancel;
    RadioButton radCDs;
    RadioButton radLoans;
    RadioButton radChecking;
    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        cDs = new CDs();
        loans = new Loans();
        checkingAccount = new CheckingAccount();

        etAccountNumber = findViewById(R.id.editAccountNumber);
        etInitBalance = findViewById(R.id.editInitBalance);
        etCurrentBalance = findViewById(R.id.editCurrentBalance);
        etPaymentAmount = findViewById(R.id.editPaymentAmount);
        etInterestRate = findViewById(R.id.editInterestRate);

        btSave = findViewById(R.id.buttonSave);
        btCancel = findViewById(R.id.buttonCancel);

        radCDs = findViewById(R.id.radioCDs);
        radLoans = findViewById(R.id.radioLoans);
        radChecking = findViewById(R.id.radioChecking);

        initDisable(); //
        initSaveButton(); //
        initCancelButton();
        initTextChangedEvent();

        radioGroup = findViewById(R.id.radioGroup);


        radioGroup.setOnCheckedChangeListener(((group, checkedId) -> {
            if (radCDs.isChecked()){
                etAccountNumber.setEnabled(true);
                etInitBalance.setEnabled(true);
                etCurrentBalance.setEnabled(true);
                etInterestRate.setEnabled(true);
                etPaymentAmount.setEnabled(false);
                btCancel.setEnabled(true);
                btSave.setEnabled(true);
            }
            else if (radChecking.isChecked()){
                etAccountNumber.setEnabled(true);
                etInitBalance.setEnabled(false);
                etCurrentBalance.setEnabled(true);
                etPaymentAmount.setEnabled(false);
                etInterestRate.setEnabled(false);
                btCancel.setEnabled(true);
                btSave.setEnabled(true);
            }
            else if (radLoans.isChecked()){
                etAccountNumber.setEnabled(true);
                etInitBalance.setEnabled(true);
                etCurrentBalance.setEnabled(true);
                etInterestRate.setEnabled(true);
                etPaymentAmount.setEnabled(true);
                btCancel.setEnabled(true);
                btSave.setEnabled(true);
            }
        }));
    }

    private void initDisable(){
        etAccountNumber.setEnabled(false);
        etInitBalance.setEnabled(false);
        etCurrentBalance.setEnabled(false);
        etInterestRate.setEnabled(false);
        etPaymentAmount.setEnabled(false);

        btCancel.setEnabled(false);
        btSave.setEnabled(false);
    }

    private void initSaveButton(){

        btSave.setOnClickListener(v -> {

            boolean wasSuccessful;

            Data ds = new Data(MainActivity.this);

            if (radCDs.isChecked()){
                try {
                    ds.open();
                    wasSuccessful = ds.insertCDs(cDs);

                    if (wasSuccessful){
                        Toast.makeText(getApplicationContext(), "Saved!" , Toast.LENGTH_SHORT).show();
                        clearTextFields();
                    }
                    else
                        Toast.makeText(getApplicationContext(), "Failed to save!" , Toast.LENGTH_SHORT).show();

                    ds.close();
                }
                catch (Exception e)
                {
                }
            }
            else if (radChecking.isChecked()){
                try {
                    ds.open();
                    wasSuccessful = ds.insertChecking(checkingAccount);

                    if (wasSuccessful){
                        Toast.makeText(getApplicationContext(), "Saved!" , Toast.LENGTH_SHORT).show();
                        clearTextFields(); // called to clear all text fields
                    }
                    else
                        Toast.makeText(getApplicationContext(), "Failed to save!" , Toast.LENGTH_SHORT).show();

                    ds.close();
                }
                catch (Exception e)
                {
                }
            }
            else if (radLoans.isChecked()){
                try {
                    ds.open();
                    wasSuccessful = ds.insertLoans(loans);


                    if (wasSuccessful){
                        Toast.makeText(getApplicationContext(), "Saved!" , Toast.LENGTH_SHORT).show();
                        clearTextFields();
                    }
                    else
                        Toast.makeText(getApplicationContext(), "Failed to save!" , Toast.LENGTH_SHORT).show();

                    ds.close();
                }
                catch (Exception e){
                }
            }
        });
    }

    private void initCancelButton(){
        btCancel.setOnClickListener(v -> {
            if (radCDs.isChecked()){
                clearTextFields();
                Toast.makeText(getApplicationContext(), "Did not Save!" , Toast.LENGTH_SHORT).show();
            }
            if (radChecking.isChecked()){
                clearTextFields();
                Toast.makeText(getApplicationContext(), "Did not Save!" , Toast.LENGTH_SHORT).show();
            }
            if (radLoans.isChecked()){
                clearTextFields();
                Toast.makeText(getApplicationContext(), "Did not Save!" , Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void clearTextFields(){
        try {
            etAccountNumber.setText("");
            Thread.sleep(1);
            etAccountNumber.requestFocus();
        }
        catch (Exception e){

        }

        try {
            etInitBalance.setText("");
            Thread.sleep(1);
        }
        catch (Exception e){

        }

        try {
            etCurrentBalance.setText("");
            Thread.sleep(1);
        }
        catch (Exception e){

        }

        try {
            etInterestRate.setText("");
            Thread.sleep(1);
        }
        catch (Exception e){

        }
        try {
            etPaymentAmount.setText("");
            Thread.sleep(1);

        }
        catch (Exception e){

        }
    }

    private void initTextChangedEvent(){
        etAccountNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (radCDs.isChecked())
                    cDs.setAccountNumber(Integer.parseInt(etAccountNumber.getText().toString()));
                if (radLoans.isChecked())
                    loans.setAccountNumber(Integer.parseInt(etAccountNumber.getText().toString()));
                if (radChecking.isChecked())
                    checkingAccount.setAccountNumber(Integer.parseInt(etAccountNumber.getText().toString()));
            }
        });

        etInitBalance.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (radCDs.isChecked())
                    cDs.setInitBalance(Double.parseDouble(etInitBalance.getText().toString()));
                if (radLoans.isChecked())
                    loans.setInitBalance(Double.parseDouble(etInitBalance.getText().toString()));
            }
        });

        etCurrentBalance.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (radCDs.isChecked())
                    cDs.setCurrentBalance(Double.parseDouble(etCurrentBalance.getText().toString()));
                if (radLoans.isChecked())
                    loans.setCurrentBalance(Double.parseDouble(etCurrentBalance.getText().toString()));
                if (radChecking.isChecked())
                    checkingAccount.setCurrentBalance(Double.parseDouble(etCurrentBalance.getText().toString()));
            }
        });

        etPaymentAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                loans.setPaymentAmount(Double.parseDouble(etPaymentAmount.getText().toString()));
            }
        });

        etInterestRate.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (radCDs.isChecked())
                    cDs.setInterestRate(Double.parseDouble(etInterestRate.getText().toString()));
                if (radLoans.isChecked())
                    loans.setInterestRate(Double.parseDouble(etInterestRate.getText().toString()));
            }
        });
    }
}